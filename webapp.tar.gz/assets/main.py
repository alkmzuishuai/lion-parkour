# coding: utf-8
import pygame
import random
import sys
import asyncio

pygame.init()

WIDTH = 480
HEIGHT = 640
FPS = 60

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("小狮子像素跑酷")
clock = pygame.time.Clock()

BLACK = (0, 0, 0)
YELLOW = (255, 210, 0)
ORANGE = (255, 140, 0)
BROWN = (120, 70, 20)
RED = (220, 40, 40)
DARK_BG = (10, 12, 20)
GOLD = (255, 223, 0)
BTN_COLOR = (40,60,100)

FONT_PATH = (
    pygame.font.match_font("microsoftyahei")
    or pygame.font.match_font("simhei")
    or pygame.font.match_font("simsun")
    or "msyhl.ttc"
)

def get_font(size):
    try:
        return pygame.font.Font(FONT_PATH, size)
    except (FileNotFoundError, pygame.error):
        return pygame.font.Font(None, size)

# 触屏按钮区域
btn_left_rect = pygame.Rect(30, HEIGHT -70,100,50)
btn_jump_rect = pygame.Rect(190, HEIGHT -70,100,50)
btn_right_rect = pygame.Rect(350, HEIGHT -70,100,50)

class PixelParticle:
    def __init__(self):
        self.x = random.randint(0, WIDTH)
        self.y = random.randint(-HEIGHT, HEIGHT)
        self.size = random.choice([2, 3, 4])
        self.speed = random.uniform(0.3, 1.2)
        self.color = random.choice([(60,60,90),(80,80,120),(100,100,140),(120,120,160),(70,90,130)])
    def update(self):
        self.y += self.speed
        if self.y > HEIGHT:
            self.y = random.randint(-20, 0)
            self.x = random.randint(0, WIDTH)
    def draw(self):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.size, self.size))

particles = [PixelParticle() for _ in range(120)]

class Lion:
    def __init__(self):
        self.width = 40
        self.height = 40
        self.lanes = [WIDTH // 6, WIDTH // 2, WIDTH * 5 // 6]
        self.lane_index = 1
        self.x = self.lanes[self.lane_index] - self.width // 2
        self.y = HEIGHT - 160
        self.is_jumping = False
        self.jump_timer = 0
        self.jump_duration = 28
        self.jump_height = 32
    def move_left(self):
        if self.lane_index > 0:
            self.lane_index -= 1
    def move_right(self):
        if self.lane_index < 2:
            self.lane_index += 1
    def jump(self):
        if not self.is_jumping:
            self.is_jumping = True
            self.jump_timer = self.jump_duration
    def update(self):
        target_x = self.lanes[self.lane_index] - self.width // 2
        self.x += (target_x - self.x) * 0.35
        if self.is_jumping:
            self.jump_timer -=1
            if self.jump_timer <=0:
                self.is_jumping = False
    def draw(self):
        draw_x = self.x
        draw_y = self.y
        if self.is_jumping:
            progress = 1 - self.jump_timer / self.jump_duration
            jump_offset = 4 * self.jump_height * progress * (1 - progress)
            draw_y -= int(jump_offset)
        pygame.draw.rect(screen, ORANGE, (draw_x + 8, draw_y + 18, 24, 18))
        pygame.draw.rect(screen, YELLOW, (draw_x + 14, draw_y + 22, 12, 10))
        pygame.draw.rect(screen, ORANGE, (draw_x + 10, draw_y + 4, 20, 16))
        pygame.draw.rect(screen, YELLOW, (draw_x + 14, draw_y + 8, 12, 10))
        pygame.draw.rect(screen, BROWN, (draw_x + 6, draw_y + 6, 4, 10))
        pygame.draw.rect(screen, BROWN, (draw_x + 30, draw_y + 6, 4, 10))
        pygame.draw.rect(screen, BROWN, (draw_x + 8, draw_y + 2, 6, 4))
        pygame.draw.rect(screen, BROWN, (draw_x + 26, draw_y + 2, 6, 4))
        pygame.draw.rect(screen, BROWN, (draw_x + 8, draw_y, 4, 6))
        pygame.draw.rect(screen, BROWN, (draw_x + 28, draw_y, 4, 6))
        pygame.draw.rect(screen, BLACK, (draw_x + 15, draw_y + 10, 3, 4))
        pygame.draw.rect(screen, BLACK, (draw_x + 22, draw_y + 10, 3, 4))
        pygame.draw.rect(screen, BLACK, (draw_x + 18, draw_y + 14, 4, 3))
        pygame.draw.rect(screen, ORANGE, (draw_x + 10, draw_y + 34, 6, 6))
        pygame.draw.rect(screen, ORANGE, (draw_x + 24, draw_y + 34, 6, 6))
        pygame.draw.rect(screen, ORANGE, (draw_x + 32, draw_y + 20, 6, 4))
        pygame.draw.rect(screen, BROWN, (draw_x + 36, draw_y + 18, 4, 4))

class Obstacle:
    def __init__(self, speed):
        self.width = 40
        self.height = 40
        self.lanes = [WIDTH // 6, WIDTH // 2, WIDTH * 5 // 6]
        self.lane_index = random.randint(0, 2)
        self.x = self.lanes[self.lane_index] - self.width // 2
        self.y = -self.height
        self.speed = speed
    def update(self):
        self.y += self.speed
    def draw(self):
        pygame.draw.rect(screen, RED, (self.x, self.y, self.width, self.height))
        pygame.draw.rect(screen, (180, 20, 20), (self.x + 4, self.y + 4, 32, 32))
    def off_screen(self):
        return self.y > HEIGHT
    def collide(self, lion):
        if lion.is_jumping:
            return False
        return lion.x < self.x+self.width-10 and lion.x+lion.width-10>self.x and lion.y<self.y+self.height-10 and lion.y+lion.height-10>self.y

class Coin:
    def __init__(self, speed):
        self.width = 24
        self.height = 24
        self.lanes = [WIDTH // 6, WIDTH // 2, WIDTH * 5 // 6]
        self.lane_index = random.randint(0,2)
        self.x = self.lanes[self.lane_index] - self.width//2
        self.y = -self.height
        self.speed = speed
        self.value = random.choice([1,3,4])
    def update(self):
        self.y += self.speed
    def draw(self):
        pygame.draw.rect(screen,GOLD,(self.x,self.y,self.width,self.height))
        pygame.draw.rect(screen,(255,180,0),(self.x+4,self.y+4,16,16))
    def off_screen(self):
        return self.y>HEIGHT
    def collide(self,lion):
        return lion.x < self.x+self.width and lion.x+lion.width>self.x and lion.y<self.y+self.height and lion.y+lion.height>self.y

def draw_ui_buttons():
    pygame.draw.rect(screen,BTN_COLOR,btn_left_rect,border_radius=8)
    pygame.draw.rect(screen,BTN_COLOR,btn_jump_rect,border_radius=8)
    pygame.draw.rect(screen,BTN_COLOR,btn_right_rect,border_radius=8)
    font = get_font(30)
    screen.blit(font.render("◀",True,(255,255,255)),(btn_left_rect.x+35,btn_left_rect.y+10))
    screen.blit(font.render("跳",True,(255,255,255)),(btn_jump_rect.x+38,btn_jump_rect.y+10))
    screen.blit(font.render("▶",True,(255,255,255)),(btn_right_rect.x+35,btn_right_rect.y+10))

async def main():
    lion = Lion()
    obstacles = []
    coins = []
    score = 0
    coin_count = 0
    spawn_timer = 0
    coin_spawn_timer = 0
    game_over = False

    while True:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            # 触屏/鼠标点击按钮
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                if not game_over:
                    if btn_left_rect.collidepoint(pos):
                        lion.move_left()
                    if btn_right_rect.collidepoint(pos):
                        lion.move_right()
                    if btn_jump_rect.collidepoint(pos):
                        lion.jump()
            if event.type == pygame.KEYDOWN:
                if not game_over:
                    if event.key in (pygame.K_a, pygame.K_LEFT):
                        lion.move_left()
                    elif event.key in (pygame.K_d, pygame.K_RIGHT):
                        lion.move_right()
                    elif event.key in (pygame.K_SPACE, pygame.K_w, pygame.K_UP):
                        lion.jump()
                if game_over and event.key == pygame.K_RETURN:
                    await main()
                    return

        if not game_over:
            lion.update()
            game_speed = 5 + score // 300
            spawn_timer +=1
            if spawn_timer >=70:
                obstacles.append(Obstacle(game_speed))
                spawn_timer =0
            coin_spawn_timer +=1
            if coin_spawn_timer >=45:
                coins.append(Coin(game_speed))
                coin_spawn_timer =0
            for obs in obstacles: obs.update()
            for c in coins: c.update()
            obstacles = [o for o in obstacles if not o.off_screen()]
            coins = [c for c in coins if not c.off_screen()]
            for obs in obstacles:
                if obs.collide(lion):
                    game_over = True
            pick = []
            for i,c in enumerate(coins):
                if c.collide(lion):
                    coin_count += c.value
                    pick.append(i)
            for idx in reversed(pick):
                del coins[idx]
            score +=1

        screen.fill(DARK_BG)
        for p in particles:
            p.update()
            p.draw()
        lane_x = [WIDTH //6,WIDTH//2,WIDTH*5//6]
        for x in lane_x:
            pygame.draw.line(screen,(40,44,60),(x,0),(x,HEIGHT),2)
        for o in obstacles: o.draw()
        for c in coins: c.draw()
        lion.draw()
        draw_ui_buttons()

        font = get_font(28)
        s_text = font.render(f"分数:{score}",True,(255,255,255))
        c_text = font.render(f"金币:{coin_count}",True,GOLD)
        screen.blit(s_text,(12,12))
        screen.blit(c_text,(12,44))

        if game_over:
            big_font = get_font(42)
            over = big_font.render("游戏结束",True,RED)
            re = font.render("按Enter重新开始",True,(255,255,255))
            screen.blit(over,(WIDTH//2-over.get_width()//2,HEIGHT//2-40))
            screen.blit(re,(WIDTH//2-re.get_width()//2,HEIGHT//2+20))
            if score > 52:
                big_font = get_font(34)
                t1 = big_font.render("天天开心",True,GOLD)
                t2 = font.render("祝你的生活中拥有乐趣",True,(255,255,255))
                screen.blit(t1,(WIDTH//2-t1.get_width()//2,HEIGHT//2-100))
                screen.blit(t2,(WIDTH//2-t2.get_width()//2,HEIGHT//2-60))
        pygame.display.flip()
        await asyncio.sleep(0)

if __name__ == "__main__":
    asyncio.run(main())